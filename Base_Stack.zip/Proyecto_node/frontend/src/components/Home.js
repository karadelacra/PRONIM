import React from 'react';

const Home = () => {
    return (
        <div>
            <h2>Bienvenido a la Aplicación</h2>
            <a href="/login">Iniciar Sesión</a>
            <br />
            <a href="/register">Registrarse</a>
        </div>
    );
};

export default Home;
