Para iniciar el server hay que entrar en back end y dar node app.js
y para ejecutar el cliente es con npm start

react maneja por rutas y archivos, todos las paginas se manejan en el frontend dentro de src y component
y el manejo de las rutas se tienen  que configurar en el app.js de front end por parte del front end

mientras que en el back end es con rutas y el controlador
